<main>

<?php
	$soma=0;

for($i=0;$i<4569;$i++){
	if($i % 3 ==0 || $i % 5 ==0){
		$soma+=$i;
		#echo $i,'<br>';
	}
}

echo $soma,'<hr>';


echo $home;

?>

</main>