<!DOCTYPE html>
<html lang="br">
<head>
<title><?=$title?></title>
<meta charset="utf-8">
<link rel="stylesheet" href="../../../bower_components/bootstrap/dist/css/bootstrap.min.css" type="text/css" />


<link rel="stylesheet" href="../../../bower_components/bootstrap-table/dist/bootstrap-table.min.css">
<link rel="stylesheet" href="../../assets/js/formvalidation/dist/css/formValidation.min.css">
<link rel="stylesheet" href="../../../bower_components/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="../../assets/css/style.css" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Dosis:400,500,600' rel='stylesheet' type='text/css'>

</head>
<body>
