<?php
echo "<pre>";
print_r($contacts);
echo "</pre>";
?>
