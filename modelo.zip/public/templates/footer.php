<footer>
  <nav>
    <h1>Navigation</h1>
    <ul>
      <li><a href="/">Home</a></li>
 
      <li><a href="/Consortium/">About W3C</a></li>
    </ul>
  </nav>
  <nav>
    <h1>Contact W3C</h1>
    <ul>
      <li><a href="/Consortium/contact">Contact</a></li>
      <li><a href="/Consortium/sup">Donate</a></li>
      <li><a href="/Consortium/siteindex">Site Map</a></li>
    </ul>
  </nav>
  <section>
    <h1>W3C Updates</h1>
    <ul>
      <li><a href="http://twitter.com/W3C">Twitter</a></li>
      <li><a href="http://identi.ca/w3c">Identi.ca</a></li>
    </ul>
  </section>
  <p class="copyright">Copyright © 2009 W3C</p>
</footer>



</body>

<script type="text/javascript" src="../../../bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="../../../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script> 
<script type="text/javascript" src="../../../bower_components/bootstrap-table/dist/bootstrap-table.js"></script>

<script type="text/javascript" src="../../assets/js/formvalidation/dist/js/formValidation.min.js"></script>
<script type="text/javascript" src="../../assets/js/formvalidation/dist/js/framework/bootstrap.min.js"></script>
<script type="text/javascript" src="../../assets/js/script.js"></script>

</html>