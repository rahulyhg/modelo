<?php
namespace API;
class Exception extends \Exception
{
}